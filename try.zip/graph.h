#ifndef GRAPH_H
#define GRAPH_H

#include <QWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QtCharts/QLineSeries>
#include <QtCharts/QChartView>
#include <QtCharts/QChart>
#include <QtCharts/QValueAxis>
#include <QRandomGenerator>
#include <QtCharts>
QT_CHARTS_USE_NAMESPACE//为了使用QChartView
#include "ui_graph.h"

typedef QPair<QPointF, QString> Data;
typedef QList<Data> DataList;
typedef QList<DataList> DataTable;

namespace Ui {
class graph;
}

class graph : public QWidget
{
    Q_OBJECT

public:
    explicit graph(QWidget *parent = nullptr);
    ~graph();
    DataTable getData( ) const;
    int getmaxh( ) const;
    int getminh( ) const;
    int getmaxz( ) const;
    int getminz( ) const;

private slots:
    void on_return_2_clicked();

private:
    Ui::graph *ui;
};

#endif // GRAPH_H
