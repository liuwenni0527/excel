#ifndef HOME_H
#define HOME_H

#include <QMainWindow>
#include <QToolBar>
#include <QAction>
#include <QMenu>
#include "graph.h"
#include <QDialog>
#include <string>
using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class home; }
QT_END_NAMESPACE

class home : public QMainWindow
{
    Q_OBJECT

public:
     QVector<QVector<QString>> list;
//    QList<QString> list_all;
//    QList<int> index_all;
    int size = 0;
    int row_length;
    int column_length;
    home(QWidget *parent = nullptr);
    ~home();

    DataTable dataTable;
    int maxheng;
    int minheng;
    int maxzong;
    int minzong;

    int flag = 0;

private slots:
    void swap_letter(string [], int [], int, int);

    void swap_num(int [], int, int);

    int compare(string, string);

    void on_copy_clicked();

    void on_sum_clicked();

    void on_replace_clicked();

    void on_add_clicked();

    void on_divide_clicked();

    void on_multiple_clicked();

    void on_minus_clicked();

    void on_create_clicked();

    void on_transpose_clicked();

    // 间隔

    void on_merge_clicked();

    void on_count_clicked();

    void on_highlight_clicked();

    void on_draw_clicked();

    void on_cancel_highlight_clicked();

    void on_cancel_merge_clicked();

    void on_read_clicked();

    void on_preserve_clicked();

    void on_removerow_clicked();

    void on_removecol_clicked();

    void on_addrow_clicked();

    void on_addcol_clicked();

    void on_ave_clicked();

    void on_max_clicked();

    void on_min_clicked();

    void on_ascend_clicked();

    void on_descend_clicked();

    void on_check_clicked();

    void bubsort_num(int [], int);

    void bubsort_letter(string [], int[], int);

private:
    Ui::home *ui;

signals:

//    void send_array(QList<QString> list, QList<int> index);

//    void send_count(int row, int column);
};
#endif // HOME_H
