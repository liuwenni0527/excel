/********************************************************************************
** Form generated from reading UI file 'home.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOME_H
#define UI_HOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_home
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_2;
    QFrame *frame;
    QVBoxLayout *verticalLayout;
    QTextEdit *textEdit;
    QTableWidget *tableWidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *home)
    {
        if (home->objectName().isEmpty())
            home->setObjectName(QString::fromUtf8("home"));
        home->setEnabled(true);
        home->resize(800, 291);
        home->setStyleSheet(QString::fromUtf8("QToolBar\n"
"{\n"
"spacing:20px;\n"
"margin-top:20px;\n"
"}\n"
"QToolBar::separator\n"
"{\n"
"    background: rgb(85, 255, 255);       /*\350\203\214\346\231\257\351\242\234\350\211\262*/\n"
"    margin: 3px 3px 3px 3px;    /*\345\244\226\350\276\271\350\267\235 \344\270\212\345\217\263\344\270\213\345\267\246*/\n"
"    width: 1px;                 /*\345\256\275\345\272\246*/\n"
"}\n"
"QMenu\n"
"{\n"
"        \n"
"	\n"
"	color: rgb(0, 0, 0);\n"
"	background-color: rgb(255, 255, 255);\n"
"    border:none;\n"
"}\n"
"QMenu::item\n"
"{\n"
"        color:rgb(0, 0, 0);\n"
"        background-color:rgb(255, 255, 255);\n"
"        width:120px;\n"
"        height:50px;\n"
"        padding-left:20px;\n"
"        /*border:4px solid rgb(70,125,200);*/\n"
"        border:4px solid rgb(255, 255, 255);\n"
"}\n"
"QMenu::item:selected\n"
"{\n"
"    color:rgb(255,255,255);\n"
"    background-color:rgb(76,131,215);\n"
"	/*background-color: rgb(85, 170, 127);*/\n"
"}\n"
"\n"
""));
        home->setToolButtonStyle(Qt::ToolButtonIconOnly);
        centralwidget = new QWidget(home);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setEnabled(true);
        horizontalLayout_2 = new QHBoxLayout(centralwidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(frame);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        textEdit = new QTextEdit(frame);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        verticalLayout->addWidget(textEdit);

        tableWidget = new QTableWidget(frame);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        verticalLayout->addWidget(tableWidget);

        verticalLayout->setStretch(0, 1);
        verticalLayout->setStretch(1, 6);

        horizontalLayout_2->addWidget(frame);

        home->setCentralWidget(centralwidget);
        menubar = new QMenuBar(home);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        home->setMenuBar(menubar);
        statusbar = new QStatusBar(home);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        home->setStatusBar(statusbar);

        retranslateUi(home);

        QMetaObject::connectSlotsByName(home);
    } // setupUi

    void retranslateUi(QMainWindow *home)
    {
        home->setWindowTitle(QCoreApplication::translate("home", "home", nullptr));
    } // retranslateUi

};

namespace Ui {
    class home: public Ui_home {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOME_H
