/****************************************************************************
** Meta object code from reading C++ file 'home.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../try/home.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'home.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_home_t {
    QByteArrayData data[37];
    char stringdata0[579];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_home_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_home_t qt_meta_stringdata_home = {
    {
QT_MOC_LITERAL(0, 0, 4), // "home"
QT_MOC_LITERAL(1, 5, 11), // "swap_letter"
QT_MOC_LITERAL(2, 17, 0), // ""
QT_MOC_LITERAL(3, 18, 8), // "string[]"
QT_MOC_LITERAL(4, 27, 5), // "int[]"
QT_MOC_LITERAL(5, 33, 8), // "swap_num"
QT_MOC_LITERAL(6, 42, 7), // "compare"
QT_MOC_LITERAL(7, 50, 6), // "string"
QT_MOC_LITERAL(8, 57, 15), // "on_copy_clicked"
QT_MOC_LITERAL(9, 73, 14), // "on_sum_clicked"
QT_MOC_LITERAL(10, 88, 18), // "on_replace_clicked"
QT_MOC_LITERAL(11, 107, 14), // "on_add_clicked"
QT_MOC_LITERAL(12, 122, 17), // "on_divide_clicked"
QT_MOC_LITERAL(13, 140, 19), // "on_multiple_clicked"
QT_MOC_LITERAL(14, 160, 16), // "on_minus_clicked"
QT_MOC_LITERAL(15, 177, 17), // "on_create_clicked"
QT_MOC_LITERAL(16, 195, 20), // "on_transpose_clicked"
QT_MOC_LITERAL(17, 216, 16), // "on_merge_clicked"
QT_MOC_LITERAL(18, 233, 16), // "on_count_clicked"
QT_MOC_LITERAL(19, 250, 20), // "on_highlight_clicked"
QT_MOC_LITERAL(20, 271, 15), // "on_draw_clicked"
QT_MOC_LITERAL(21, 287, 27), // "on_cancel_highlight_clicked"
QT_MOC_LITERAL(22, 315, 23), // "on_cancel_merge_clicked"
QT_MOC_LITERAL(23, 339, 15), // "on_read_clicked"
QT_MOC_LITERAL(24, 355, 19), // "on_preserve_clicked"
QT_MOC_LITERAL(25, 375, 20), // "on_removerow_clicked"
QT_MOC_LITERAL(26, 396, 20), // "on_removecol_clicked"
QT_MOC_LITERAL(27, 417, 17), // "on_addrow_clicked"
QT_MOC_LITERAL(28, 435, 17), // "on_addcol_clicked"
QT_MOC_LITERAL(29, 453, 14), // "on_ave_clicked"
QT_MOC_LITERAL(30, 468, 14), // "on_max_clicked"
QT_MOC_LITERAL(31, 483, 14), // "on_min_clicked"
QT_MOC_LITERAL(32, 498, 17), // "on_ascend_clicked"
QT_MOC_LITERAL(33, 516, 18), // "on_descend_clicked"
QT_MOC_LITERAL(34, 535, 16), // "on_check_clicked"
QT_MOC_LITERAL(35, 552, 11), // "bubsort_num"
QT_MOC_LITERAL(36, 564, 14) // "bubsort_letter"

    },
    "home\0swap_letter\0\0string[]\0int[]\0"
    "swap_num\0compare\0string\0on_copy_clicked\0"
    "on_sum_clicked\0on_replace_clicked\0"
    "on_add_clicked\0on_divide_clicked\0"
    "on_multiple_clicked\0on_minus_clicked\0"
    "on_create_clicked\0on_transpose_clicked\0"
    "on_merge_clicked\0on_count_clicked\0"
    "on_highlight_clicked\0on_draw_clicked\0"
    "on_cancel_highlight_clicked\0"
    "on_cancel_merge_clicked\0on_read_clicked\0"
    "on_preserve_clicked\0on_removerow_clicked\0"
    "on_removecol_clicked\0on_addrow_clicked\0"
    "on_addcol_clicked\0on_ave_clicked\0"
    "on_max_clicked\0on_min_clicked\0"
    "on_ascend_clicked\0on_descend_clicked\0"
    "on_check_clicked\0bubsort_num\0"
    "bubsort_letter"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_home[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      32,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    4,  174,    2, 0x08 /* Private */,
       5,    3,  183,    2, 0x08 /* Private */,
       6,    2,  190,    2, 0x08 /* Private */,
       8,    0,  195,    2, 0x08 /* Private */,
       9,    0,  196,    2, 0x08 /* Private */,
      10,    0,  197,    2, 0x08 /* Private */,
      11,    0,  198,    2, 0x08 /* Private */,
      12,    0,  199,    2, 0x08 /* Private */,
      13,    0,  200,    2, 0x08 /* Private */,
      14,    0,  201,    2, 0x08 /* Private */,
      15,    0,  202,    2, 0x08 /* Private */,
      16,    0,  203,    2, 0x08 /* Private */,
      17,    0,  204,    2, 0x08 /* Private */,
      18,    0,  205,    2, 0x08 /* Private */,
      19,    0,  206,    2, 0x08 /* Private */,
      20,    0,  207,    2, 0x08 /* Private */,
      21,    0,  208,    2, 0x08 /* Private */,
      22,    0,  209,    2, 0x08 /* Private */,
      23,    0,  210,    2, 0x08 /* Private */,
      24,    0,  211,    2, 0x08 /* Private */,
      25,    0,  212,    2, 0x08 /* Private */,
      26,    0,  213,    2, 0x08 /* Private */,
      27,    0,  214,    2, 0x08 /* Private */,
      28,    0,  215,    2, 0x08 /* Private */,
      29,    0,  216,    2, 0x08 /* Private */,
      30,    0,  217,    2, 0x08 /* Private */,
      31,    0,  218,    2, 0x08 /* Private */,
      32,    0,  219,    2, 0x08 /* Private */,
      33,    0,  220,    2, 0x08 /* Private */,
      34,    0,  221,    2, 0x08 /* Private */,
      35,    2,  222,    2, 0x08 /* Private */,
      36,    3,  227,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 4, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 4, QMetaType::Int, QMetaType::Int,    2,    2,    2,
    QMetaType::Int, 0x80000000 | 7, 0x80000000 | 7,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4, QMetaType::Int,    2,    2,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 4, QMetaType::Int,    2,    2,    2,

       0        // eod
};

void home::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<home *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->swap_letter((*reinterpret_cast< string(*)[]>(_a[1])),(*reinterpret_cast< int(*)[]>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 1: _t->swap_num((*reinterpret_cast< int(*)[]>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 2: { int _r = _t->compare((*reinterpret_cast< string(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 3: _t->on_copy_clicked(); break;
        case 4: _t->on_sum_clicked(); break;
        case 5: _t->on_replace_clicked(); break;
        case 6: _t->on_add_clicked(); break;
        case 7: _t->on_divide_clicked(); break;
        case 8: _t->on_multiple_clicked(); break;
        case 9: _t->on_minus_clicked(); break;
        case 10: _t->on_create_clicked(); break;
        case 11: _t->on_transpose_clicked(); break;
        case 12: _t->on_merge_clicked(); break;
        case 13: _t->on_count_clicked(); break;
        case 14: _t->on_highlight_clicked(); break;
        case 15: _t->on_draw_clicked(); break;
        case 16: _t->on_cancel_highlight_clicked(); break;
        case 17: _t->on_cancel_merge_clicked(); break;
        case 18: _t->on_read_clicked(); break;
        case 19: _t->on_preserve_clicked(); break;
        case 20: _t->on_removerow_clicked(); break;
        case 21: _t->on_removecol_clicked(); break;
        case 22: _t->on_addrow_clicked(); break;
        case 23: _t->on_addcol_clicked(); break;
        case 24: _t->on_ave_clicked(); break;
        case 25: _t->on_max_clicked(); break;
        case 26: _t->on_min_clicked(); break;
        case 27: _t->on_ascend_clicked(); break;
        case 28: _t->on_descend_clicked(); break;
        case 29: _t->on_check_clicked(); break;
        case 30: _t->bubsort_num((*reinterpret_cast< int(*)[]>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 31: _t->bubsort_letter((*reinterpret_cast< string(*)[]>(_a[1])),(*reinterpret_cast< int(*)[]>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject home::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_home.data,
    qt_meta_data_home,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *home::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *home::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_home.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int home::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 32)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 32;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
