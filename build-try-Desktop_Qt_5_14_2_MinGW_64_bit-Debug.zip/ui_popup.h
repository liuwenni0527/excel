/********************************************************************************
** Form generated from reading UI file 'popup.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_POPUP_H
#define UI_POPUP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_popup
{
public:
    QLineEdit *search;
    QLineEdit *replace;
    QLabel *label;
    QLabel *label_2;
    QPushButton *replace_all;
    QPushButton *replace_this;
    QPushButton *search_all;
    QPushButton *search_next;
    QCheckBox *case_sensitive;
    QCheckBox *cell_match;
    QTableWidget *tableWidget;

    void setupUi(QWidget *popup)
    {
        if (popup->objectName().isEmpty())
            popup->setObjectName(QString::fromUtf8("popup"));
        popup->resize(400, 300);
        search = new QLineEdit(popup);
        search->setObjectName(QString::fromUtf8("search"));
        search->setGeometry(QRect(120, 100, 113, 20));
        replace = new QLineEdit(popup);
        replace->setObjectName(QString::fromUtf8("replace"));
        replace->setGeometry(QRect(120, 140, 113, 20));
        label = new QLabel(popup);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 100, 54, 12));
        label_2 = new QLabel(popup);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 140, 54, 12));
        replace_all = new QPushButton(popup);
        replace_all->setObjectName(QString::fromUtf8("replace_all"));
        replace_all->setGeometry(QRect(10, 190, 80, 20));
        replace_this = new QPushButton(popup);
        replace_this->setObjectName(QString::fromUtf8("replace_this"));
        replace_this->setGeometry(QRect(99, 189, 81, 21));
        search_all = new QPushButton(popup);
        search_all->setObjectName(QString::fromUtf8("search_all"));
        search_all->setGeometry(QRect(190, 190, 80, 20));
        search_next = new QPushButton(popup);
        search_next->setObjectName(QString::fromUtf8("search_next"));
        search_next->setGeometry(QRect(280, 190, 80, 20));
        case_sensitive = new QCheckBox(popup);
        case_sensitive->setObjectName(QString::fromUtf8("case_sensitive"));
        case_sensitive->setGeometry(QRect(270, 100, 73, 18));
        cell_match = new QCheckBox(popup);
        cell_match->setObjectName(QString::fromUtf8("cell_match"));
        cell_match->setGeometry(QRect(270, 140, 73, 18));
        tableWidget = new QTableWidget(popup);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(80, 220, 256, 192));

        retranslateUi(popup);

        QMetaObject::connectSlotsByName(popup);
    } // setupUi

    void retranslateUi(QWidget *popup)
    {
        popup->setWindowTitle(QCoreApplication::translate("popup", "Form", nullptr));
        label->setText(QCoreApplication::translate("popup", "\346\237\245\346\211\276", nullptr));
        label_2->setText(QCoreApplication::translate("popup", "\346\233\277\346\215\242\344\270\272", nullptr));
        replace_all->setText(QCoreApplication::translate("popup", "\345\205\250\351\203\250\346\233\277\346\215\242", nullptr));
        replace_this->setText(QCoreApplication::translate("popup", "\346\233\277\346\215\242", nullptr));
        search_all->setText(QCoreApplication::translate("popup", "\346\237\245\346\211\276\345\205\250\351\203\250", nullptr));
        search_next->setText(QCoreApplication::translate("popup", "\346\237\245\346\211\276\344\270\213\344\270\200\344\270\252", nullptr));
        case_sensitive->setText(QCoreApplication::translate("popup", "\345\244\247\345\260\217\345\206\231\346\225\217\346\204\237", nullptr));
        cell_match->setText(QCoreApplication::translate("popup", "\345\215\225\345\205\203\346\240\274\345\214\271\351\205\215", nullptr));
    } // retranslateUi

};

namespace Ui {
    class popup: public Ui_popup {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_POPUP_H
